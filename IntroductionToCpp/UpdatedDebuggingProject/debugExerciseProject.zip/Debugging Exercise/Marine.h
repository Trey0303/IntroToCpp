#pragma once

class Marine
{
public:
	Marine();
	~Marine();

	int attack();
	void takeDamage(int damage);

};

